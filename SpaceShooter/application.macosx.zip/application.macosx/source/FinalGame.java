import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FinalGame extends PApplet {

PVector[] stars = new PVector[250];
SpaceShip user = new SpaceShip();
Boolean state = false;
Boolean overText = false;
PFont helveticaNeue;
ArrayList<Bullet> bullets = new ArrayList<Bullet>();
ArrayList<Enemies> enemies = new ArrayList<Enemies>();
int bulletCount = 0;
ForceField shield = new ForceField();
int s, c, h;
int napTime = 3000;
String playerState = "Welcome";
int score;
String difficulty = "Easy";
Boolean overEasy = false;
Boolean overMedium = false;
Boolean overHard = false;
float angle = 1.15f;
float angle1 = 0.99f;
float angle2 = 0.89f;
float angle3 = 0.79f;
float angle4 = 0.69f;
float speed = 0.030f;
int constant = 450;
int scalar = 300;
float xPlane = width/2;
float yPlane = height/2;
PImage shipPic, jupiter;
PImage smoke1, smoke2, smoke3, smoke4;
float xSmoke1, ySmoke1, xSmoke2, ySmoke2, xSmoke3, ySmoke3, xSmoke4, ySmoke4;
Eye eye1, eye2;
HowTo how;
Boolean overPause = false;
Boolean pause = false;
Pause call;



public void setup() {
  
  how = new HowTo();
  background(0);
  fill(255);
  call = new Pause();
  for (int i = 0; i < 250; i++) {
    stars[i] = new PVector(random(width), random(height));
  }
  textSize(25);
  
  text("Difficulty", width-150, 90);
  text("Easy", width-120, 125);
  text("Medium", width-120, 160);
  text("Hard", width-120, 195);
  shipPic = loadImage("spaceShipMenu.jpg");
  smoke1 = loadImage("smoke1.jpg");
  smoke1.resize(30, 30);
  smoke2 = loadImage("smoke2.jpg");
  smoke2.resize(30, 30);
  smoke3 = loadImage("smoke3.jpg");
  smoke3.resize(30, 30);
  smoke4 = loadImage("smoke4.jpg");
  smoke4.resize(30, 30);
  jupiter = loadImage("Jupiter.jpg");
  eye1 = new Eye(70, 120, 120);
  eye2 = new Eye(200, 90, 90);
}

public void draw() {
  //Gameplay state
  if (state) {
    if (pause) {
      call.pause(difficulty);
      call.checkPause(mouseX, mouseY);
    } else {
      noStroke();
      background(RGB);
      textSize(40);
      fill(205, 133, 63);
      text("Score: " + score, 100, 100);
      text("Shield state: " + shield.state, 100, 150);
      int winScore = 50;
      int scoreToWin = winScore - score;
      text("To win: " + scoreToWin, 100, 200 );
      stroke(255);
      strokeWeight(1);
      for (int i = 0; i < 250; i++) {
        point(stars[i].x, stars[i].y);
      }
      stroke(205, 133, 63);
      strokeWeight(7);
      line(width-80, 80, width-80, 100);
      line(width-90, 80, width-90, 100);
      strokeWeight(1);
      if (mouseX>width-94 && mouseX<width-73 && mouseY>80 && mouseY<106) {
        overPause = true;
        stroke(0, 133, 63);
        strokeWeight(7);
        line(width-80, 80, width-80, 100);
        line(width-90, 80, width-90, 100);
        strokeWeight(1);
      } else {
        overPause=false;
      }
      for (Enemies enemy : enemies) {
        Boolean n = enemy.checkLose();
        if (n) {
          delay(500);
          playerState = "You Lose";
          state = false;
          score = 0;
          bullets = new ArrayList<Bullet>();
          enemies = new ArrayList<Enemies>();
          shield = new ForceField();
        }
      }
      for (int i = enemies.size()-1; i>=0; i--) {
        Boolean collide = enemies.get(i).collisionDetection(bullets);
        if (collide) {
          int sc = enemies.get(i).score();
          if (sc==1) {
            score++;
          }
          if (sc==2) {
            score=score+2;
          }
          if (sc==0) {
            shield.healthUp();
          }
          enemies.remove(i);
        }
      }
      if (difficulty.equals("Easy")) {
        c = (int)random(250);
        s = (int)random(125);
        h = (int)random(800);
      } else if (difficulty.equals("Medium")) {
        c = (int)random(200);
        s = (int)random(90);
        h = (int)random(900);
      } else if (difficulty.equals("Hard")) {
        c = (int)random(80);
        s = (int)random(40);
        h = (int)random(1000);
      }

      //Creating enemies at random instances
      if (s==1)enemies.add(new Enemies("rock"));
      if (c==1)enemies.add(new Enemies("ship"));
      if (h==1)enemies.add(new Enemies("orb"));
      user.drawSpaceShip();
      shield.drawShield();
      for (Bullet bullet : bullets) bullet.drawBullet();  //drawing bullets
      for (Enemies enemy : enemies) enemy.drawEnemy();  //drawing enemies

      if (!shield.state.equals("Nill")) {              //checking for shield collision
        for (int i = enemies.size()-1; i>=0; i--) {
          Enemies e = shield.collisionDetection(enemies.get(i));
          if (e!=null) {
            if (enemies.get(i).shapeType.equals("rock")||enemies.get(i).shapeType.equals("ship")) {
              shield.collision();
            }
            enemies.remove(e);
          }
        }
      }
      if (score>=winScore) {
        this.win();
      }
    }
  }





  //Menu state
  else if (!state) {
    if (mouseX > width/2-195 && mouseX < width/2+210 && mouseY > height/2-75 && mouseY < height/2+30) {
      overText = true;
      background(205, 133, 63);
      how.display();
      xPlane = width/2+ sin(angle)*scalar;
      yPlane = height/2 + cos(angle)*scalar;
      xSmoke1 = width/2+ sin(angle1)*scalar;
      ySmoke1 = height/2 + cos(angle1)*scalar;
      xSmoke2 = width/2+ sin(angle2)*scalar;
      ySmoke2 = height/2 + cos(angle2)*scalar;
      xSmoke3 = width/2+ sin(angle3)*scalar;
      ySmoke3 = height/2 + cos(angle3)*scalar;
      xSmoke4 = width/2+ sin(angle4)*scalar;
      ySmoke4 = height/2 + cos(angle4)*scalar;
      angle= angle + speed;
      angle1 = angle1 + speed;
      angle2 = angle2 + speed;
      angle3 = angle3 + speed;
      angle4 = angle4 + speed;
      shipPic.resize(75, 75);
      float x = width/2;
      float y = height/2;
      pushMatrix();
      translate(xPlane, yPlane);
      float Rotangle = atan2(x-xPlane, y-yPlane);
      Rotangle = Rotangle+PI/2;
      rotate(-Rotangle);
      imageMode(CENTER);
      image(shipPic, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke1, ySmoke1);
      float sAngle1 = atan2(x-xSmoke1, y-ySmoke1);
      sAngle1 = sAngle1+PI/2;
      rotate(-sAngle1);
      imageMode(CENTER);
      image(smoke1, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke2, ySmoke2);
      float sAngle2 = atan2(x-xSmoke2, y-ySmoke2);
      sAngle2 = sAngle2+PI/2;
      rotate(-sAngle2);
      imageMode(CENTER);
      image(smoke2, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke3, ySmoke3);
      float sAngle3 = atan2(x-xSmoke3, y-ySmoke3);
      sAngle3 = sAngle3+PI/2;
      rotate(-sAngle3);
      imageMode(CENTER);
      image(smoke3, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke4, ySmoke4);
      float sAngle4 = atan2(x-xSmoke4, y-ySmoke4);
      sAngle4 = sAngle4+PI/2;
      rotate(-sAngle4);
      imageMode(CENTER);
      image(smoke4, 0, 0);
      popMatrix();
      helveticaNeue = createFont("cursive", 130);
      textFont(helveticaNeue);
      fill(0, 0, 255);
      text("START", width/2-200, height/2+25);
      fill(255, 0, 0);
      text("START", width/2-195, height/2+25);
      fill(0, 255, 0);
      text("START", width/2-190, height/2+25);
      textSize(30);
      fill(255);

      text("Difficulty", width-170, 90);
      if (difficulty.equals("Easy")) {
        fill(0, 255, 0);
        text("Easy", width-150, 125);
      } else if (difficulty.equals("Medium")) {
        fill(255, 140, 0);
        text("Medium", width-150, 160);
      } else {
        fill(255, 0, 0);
        text("Hard", width-150, 195);
      }

      if (playerState.equals("Welcome")) {
        textSize(70);  
        fill(255);
        text(playerState, width/2-150, height/2-115);
      } else if (playerState.equals("You Lose")) {
        textSize(70);
        fill(0, 0, 255);  
        text(playerState, width/2-145, height/2-115);
        fill(255, 0, 0);
        text(playerState, width/2-150, height/2-115);
      } else if (playerState.equals("You Win")) {
        textSize(70);
        fill(0, 0, 255);
        text(playerState, width/2-145, height/2-115);
        fill(0, 255, 0);
        text(playerState, width/2-150, height/2-115);
      }
    } else {
      background(205, 133, 63);
      how.display();
      xPlane = width/2+ sin(angle)*scalar;
      yPlane = height/2 + cos(angle)*scalar;
      xSmoke1 = width/2+ sin(angle1)*scalar;
      ySmoke1 = height/2 + cos(angle1)*scalar;
      xSmoke2 = width/2+ sin(angle2)*scalar;
      ySmoke2 = height/2 + cos(angle2)*scalar;
      xSmoke3 = width/2+ sin(angle3)*scalar;
      ySmoke3 = height/2 + cos(angle3)*scalar;
      xSmoke4 = width/2+ sin(angle4)*scalar;
      ySmoke4 = height/2 + cos(angle4)*scalar;
      angle= angle + speed;
      angle1 = angle1 + speed;
      angle2 = angle2 + speed;
      angle3 = angle3 + speed;
      angle4 = angle4 + speed;
      shipPic.resize(75, 75);
      float x = width/2;
      float y = height/2;
      pushMatrix();
      translate(xPlane, yPlane);
      float Rotangle = atan2(x-xPlane, y-yPlane);
      Rotangle = Rotangle+PI/2;
      rotate(-Rotangle);
      imageMode(CENTER);
      image(shipPic, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke1, ySmoke1);
      float sAngle1 = atan2(x-xSmoke1, y-ySmoke1);
      sAngle1 = sAngle1+PI/2;
      rotate(-sAngle1);
      imageMode(CENTER);
      image(smoke1, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke2, ySmoke2);
      float sAngle2 = atan2(x-xSmoke2, y-ySmoke2);
      sAngle2 = sAngle2+PI/2;
      rotate(-sAngle2);
      imageMode(CENTER);
      image(smoke2, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke3, ySmoke3);
      float sAngle3 = atan2(x-xSmoke3, y-ySmoke3);
      sAngle3 = sAngle3+PI/2;
      rotate(-sAngle3);
      imageMode(CENTER);
      image(smoke3, 0, 0);
      popMatrix();
      pushMatrix();
      translate(xSmoke4, ySmoke4);
      float sAngle4 = atan2(x-xSmoke4, y-ySmoke4);
      sAngle4 = sAngle4+PI/2;
      rotate(-sAngle4);
      imageMode(CENTER);
      image(smoke4, 0, 0);
      popMatrix();
      overText = false;
      textSize(600);
      helveticaNeue = createFont("cursive", 130);
      fill(255);
      stroke(255);
      textFont(helveticaNeue);
      text("START", width/2-200, height/2+25);
      textSize(30);      
      text("Difficulty", width-170, 90);
      fill(255);
      if (overEasy||difficulty.equals("Easy")) {
        fill(0, 255, 0);
      }
      text("Easy", width-150, 125);
      fill(255);
      if (overMedium||difficulty.equals("Medium")) {
        fill(255, 140, 0);
      }
      text("Medium", width-150, 160);
      fill(255);
      if (overHard||difficulty.equals("Hard")) {
        fill(255, 0, 0);
      }
      text("Hard", width-150, 195);
      fill(255);
    }
    if (mouseX>width-150 && mouseX< width-40) {
      if (mouseY > 100 && mouseY < 125) {
        overEasy = true;
      } else if (mouseY > 135 && mouseY < 160) {
        overMedium = true;
      } else if (mouseY > 170 && mouseY < 195) {
        overHard = true;
      } else {
        overEasy = false;
        overMedium = false;
        overHard = false;
      }
    } else {
      overEasy = false;
      overMedium = false;
      overHard = false;
    }

    jupiter.resize(500, 500);
    image(jupiter, 50, 150);
    eye1.update(xPlane, yPlane);
    eye2.update(xPlane, yPlane);
    eye1.display();
    eye2.display();
    if (playerState.equals("Welcome")) {
      textSize(70);  
      fill(255);
      text(playerState, width/2-150, height/2-115);
    } else if (playerState.equals("You Lose")) {
      textSize(70);
      fill(0, 0, 255);  
      text(playerState, width/2-145, height/2-115);
      fill(255, 0, 0);
      text(playerState, width/2-150, height/2-115);
    } else if (playerState.equals("You Win")) {
      textSize(70);
      fill(0, 0, 255);
      text(playerState, width/2-145, height/2-115);
      fill(0, 255, 0);
      text(playerState, width/2-150, height/2-115);
    }
  }
}

//Check for button press and bullet shoot 
public void mousePressed() {
  if (!state) {
    if (overEasy) {
      difficulty="Easy";
    }
    if (overMedium) {
      difficulty="Medium";
    }
    if (overHard) {
      difficulty="Hard";
    }
    if (overText) {
      state = true;
    } else {
      state = false;
    }
  } else if (pause) {
    if (call.overMenu) {
      playerState = "Welcome";
      state=false;
      pause = false;
      score = 0;
      bullets = new ArrayList<Bullet>();
      enemies = new ArrayList<Enemies>();
      shield = new ForceField();
    } else if (call.overRestart) {
      score = 0;
      bullets = new ArrayList<Bullet>();
      enemies = new ArrayList<Enemies>();
      shield = new ForceField();
      pause = false;
    } else if (call.overContinue) {
      pause = false;
      state = true;
    } else if (call.overEasy) {
      difficulty = "Easy";
    } else if (call.overMedium) {
      difficulty = "Medium";
    } else if (call.overHard) {
      difficulty = "Hard";
    }
  } else if (state) {
    if (overPause) {
      pause = true;
    } else {
      bullets.add(new Bullet(mouseX, mouseY));
    }
  }
}

public void win() {
  delay(500);
  playerState = "You Win";
  state=false;
  score = 0;
  bullets = new ArrayList<Bullet>();
  enemies = new ArrayList<Enemies>();
  shield = new ForceField();
}
class Bullet {
  float mousex, mousey;
  float bulletX, bulletY;
  float m, yLeft, yRight, xTop, xBot;
  float angle;
  float xPos, yPos;
  int c =0;

  Bullet(float x, float y) {
    bulletX = width/2;
    bulletY = height/2;
    mousex = x;
    mousey = y;
  }

  public void drawBullet() {
    angle = atan2(width/2-mousex, height/2-mousey);
    angle = angle+PI/2;
    float xMovement = 15*cos(angle);
    float yMovement = 15*sin(-angle);
    bulletX = bulletX + xMovement;
    bulletY = bulletY + yMovement;
    strokeWeight(3);
    if (c==0) {
      stroke(255, 0, 0);
      c=1;
    } else if (c==1) {
      stroke(0, 255, 0);
      c=2;
    } else {
      stroke(0, 0, 255);
      c=0;
    }
    point(bulletX, bulletY);
  }
}
class Enemies {
  String shapeType;
  PImage enemy;
  float xPos, yPos;
  float angle;
  float userX=width/2, userY=height/2;
  int imageSize;
  Boolean damaged = false;
  float speedR = 2.9f;
  float speedS = 3.5f;
  int speedO = 4;
  
  Enemies(String shape) {
    shapeType = shape;
    if (shapeType.equals("rock")) {
      enemy = loadImage("moonRock.png");
      enemy.resize(30, 30);
      imageSize = 30;
    } else if (shapeType.equals("ship")) {
      enemy = loadImage("enemyShip.png");
      enemy.resize(30, 30);
      imageSize = 30;
      } else if (shapeType.equals("diamond")) {
      enemy = loadImage("enemyShip.png");
      enemy.resize(30, 30);
      imageSize = 30;
    } else {
      enemy = loadImage("glowingOrb.png");
      enemy.resize(30, 30);
      imageSize = 30;
    }
    int chance = (int)(random(0, 4));
    if (chance==0) {  //comes from the top of the screen
      xPos = random(width);
      yPos = 0;
    } else if (chance==1) {  //comes from the right hand side of the screen
      xPos = width;
      yPos = random(height);
    } else if (chance==2) {  //comes from the bottom of the screen
      xPos = random(width);
      yPos = height;
    } else {  //comes from the left hand side of the screen
      xPos = 0;
      yPos = random(height);
    }
  }

  public void drawEnemy() {

    if (shapeType.equals("rock")) {
      angle = atan2(xPos-userX, yPos-userY);
      angle = angle+PI/2;
      float xMovement = speedR*cos(angle);
      float yMovement = speedR*sin(-angle);
      xPos = xPos + xMovement;
      yPos = yPos + yMovement;
      image(enemy, xPos, yPos);
    } else if (shapeType.equals("ship")) {
      pushMatrix();
      angle = atan2(xPos-userX, yPos-userY);
      angle = angle+PI/2;
      float xMovement = speedS*cos(angle);
      float yMovement = speedS*sin(-angle);
      xPos = xPos + xMovement;
      yPos = yPos + yMovement;
      float angleRotate = atan2(userX-xPos, userY-yPos);
      angleRotate = angleRotate + PI;
      translate(xPos, yPos);
      rotate(-angleRotate);
      image(enemy, 0, 0);
      popMatrix();
    } else {
      angle = atan2(xPos-userX, yPos-userY);
      angle = angle+PI/2;
      float xMovement = speedO*cos(angle);
      float yMovement = speedO*sin(-angle);
      xPos = xPos + xMovement;
      yPos = yPos + yMovement;
      image(enemy, xPos, yPos);
    }
  }
  
  public Boolean collisionDetection(ArrayList<Bullet> bullet){
    for(Bullet pellet: bullet){
        if(pellet.bulletX > xPos-15 && pellet.bulletX < xPos+15 && pellet.bulletY > yPos-15 && pellet.bulletY < yPos+15){
          return true;
        }
    }
    return false;
  }
  
  public int score(){
    if(shapeType.equals("rock")){
      return 1;
    }
    else if (shapeType.equals("ship")){
      return 2;
    }
    else{
      return 0;
    }
  }
    public Boolean checkLose() {
    if (!enemy.equals("orb")) {
      if (xPos>width/2-5 && xPos<width/2+5 && yPos>height/2-5 && yPos<height/2+5) {
        return true;
      }
      return false;
    } else {
      return false;
    }
  }

}
class Eye{
  float ex, ey;
  int size;
  float angle = 0.0f;
  
  Eye(int x, int y, int s){
  ex=x;
  ey=y;
  size=s;
  }
    
    public void update(float sx, float sy){
    angle = atan2(sy-ey, sx-ex);
  }
  
  public void display(){
    pushMatrix();
    translate(ex, ey);
    fill(255);
    ellipse(0, 0, size, size);
    rotate(angle);
    fill(0);
    ellipse(size/4, 0, size/2, size/2);
    popMatrix();
  }
  
}
class ForceField {
  String state = "Full";
  float x=width/2, y=height/2;
  int r = 200;

  ForceField() {
  }

  public Enemies collisionDetection(Enemies e) {
    stroke(255);
    if (dist(width/2, height/2, e.xPos, e.yPos) < 115) {
      return e;
    }
    return null;
  }

  public void drawShield() {
    if (state.equals("Full")) {
      pushMatrix();
      noFill();
      stroke(0, 255, 0);
      strokeWeight(2);
      ellipseMode(CENTER);
      translate(width/2, height/2);
      ellipse(0, 0, r, r);
      popMatrix();
    } else if (state.equals("Damaged")) {
      pushMatrix();
      noFill();
      strokeWeight(2);
      stroke(150, 69, 0);
      ellipseMode(CENTER);
      translate(width/2, height/2);
      ellipse(0, 0, r, r);
      popMatrix();
    } else if (state.equals("Failing")) {
      pushMatrix();
      noFill();
      strokeWeight(2);
      stroke(255, 0, 0);
      ellipseMode(CENTER);
      translate(width/2, height/2);
      ellipse(0, 0, r, r);
      popMatrix();
    } else {
      //do nada
    }
  }

  public void healthUp() {
    if (state.equals("Failing")) {
      state = "Damaged";
    } else if (state.equals("Damaged")) {
      state = "Full";
    } else if (state.equals("Nill")) {
      state = "Failing";
    }
  }

  public void collision() {
    if (state.equals("Full")) {
      state = "Damaged";
    } else if (state.equals("Damaged")) {
      state = "Failing";
    } else if (state.equals("Failing")) {
      state = "Nill";
    }
  }
}
class HowTo {
  PImage apoint;
  PImage spoint;
  PImage health;  

  HowTo() {
    apoint = loadImage("moonRock.png");
    apoint.resize(40, 40);
    spoint = loadImage("enemyShip.png");
    spoint.resize(40, 40);
    health = loadImage("glowingOrb.png");
    health.resize(40, 40);
  }

  public void display() {    
    fill(0, 155);
    textSize(50);
    text("Key", width/2-180, height/2+95);
    image(apoint, width/2-45, height/2+85);
    image(spoint, width/2-45, height/2+135);
    image(health, width/2-45, height/2+185);
    textSize(20);
    text("Enemy: 1 Point", width/2-10, height/2+90);
    text("Enemy: 2 Points", width/2-10, height/2+140);
    text("Shoot for Health", width/2-10, height/2+190);
  }
}
class Pause {
  Boolean overMenu = false;
  Boolean overRestart = false;
  Boolean overContinue = false;
  Boolean overEasy = false;
  Boolean overMedium = false;
  Boolean overHard = false;
  String difficulty;
  PImage arrow; 

  Pause() {
    arrow = loadImage("arrow.jpg");
    arrow.resize(40, 35);
  }

  public void pause(String d) {
    difficulty = d;
    background(205, 133, 63);      
    stroke(150);
    fill(195);
    rect(width/2-350, height/2-175, 700, 350);
    textSize(90);
    fill(135, 206, 235);
    text("Paused", width/2-135, height/2-250);
    textSize(50);
    fill(0, 150);
    text("Menu", width/2-245, height/2-90);
    text("Restart", width/2-260, height/2);
    text("Continue", width/2-279, height/2+90);
    fill(0);
    textSize(30);
    text("Change Difficulty", width/2+25, height/2-100);
    textSize(40);
    if (difficulty.equals("Easy")) {
      fill(0, 255, 0);
      text("Easy", width/2+100, height/2-30);
      fill(0, 150);
      text("Medium", width/2+75, height/2+30);
      text("Hard", width/2+95, height/2+90);
    } else  if (difficulty.equals("Medium")) {
      fill(255, 140, 0);
      text("Medium", width/2+75, height/2+30);
      fill(0, 150);
      text("Easy", width/2+100, height/2-30);
      text("Hard", width/2+95, height/2+90);
    } else {
      fill(255, 0, 0);
      text("Hard", width/2+95, height/2+90);
      fill(0, 150);
      text("Easy", width/2+100, height/2-30);
      text("Medium", width/2+75, height/2+30);
    }
  }

  public void checkPause(int mx, int my) {
    if (mx>width/2-245 && mx<width/2-115 && my>height/2-125 && my<height/2-85) {
      textSize(50);
      fill(0);
      text("Menu", width/2-245, height/2-90);
      image(arrow, width/2-270, height/2-110);
      overEasy = false;
      overMedium = false;
      overHard = false;
      overRestart = false;
      overMenu = true;
      overContinue = false;
    } else if (mx>width/2-255 && mx<width/2-85 && my>height/2-30 && my<height/2+5) {
      textSize(50);
      fill(0);
      text("Restart", width/2-260, height/2);
      image(arrow, width/2-285, height/2-20);
      overEasy = false;
      overMedium = false;
      overHard = false;
      overRestart = true;
      overMenu = false;
      overContinue = false;
    } else if (mx>width/2-275 && mx<width/2-65 && my>height/2+49 && my<height/2+95) {
      textSize(50);
      fill(0);
      text("Continue", width/2-279, height/2+90);
      image(arrow, width/2-305, height/2+70);
      overEasy = false;
      overMedium = false;
      overHard = false;
      overRestart = false;
      overMenu = false;
      overContinue = true;
    } else if (mx>width/2+77 && mx<width/2+228 && my>height/2+3 && my<height/2+33) {
      textSize(40);
      fill(255, 140, 0);
      text("Medium", width/2+75, height/2+30);
      image(arrow, width/2+50, height/2+15);
      overEasy = false;
      overMedium = true;
      overHard = false;
      overRestart = false;
      overMenu = false;
      overContinue = false;
    } else if (mx>width/2+103 && mx<width/2+185 && my>height/2-60 && my<height/2-30) {
      textSize(40);
      fill(0, 255, 0);
      text("Easy", width/2+100, height/2-30);
      image(arrow, width/2+75, height/2-45);
      overEasy = true;
      overMedium = false;
      overHard = false;
      overRestart = false;
      overMenu = false;
      overContinue = false;
    } else if (mx>width/2+97 && mx<width/2+187 && my>height/2+63 && my<height/2+93) {
      textSize(40);
      fill(255, 0, 0);
      text("Hard", width/2+95, height/2+90);
      image(arrow, width/2+70, height/2+75);
      overEasy = false;
      overMedium = false;
      overHard = true;
      overRestart = false;
      overMenu = false;
      overContinue = false;
    } else {
      overEasy = false;
      overMedium = false;
      overHard = false;
      overRestart = false;
      overMenu = false;
      overContinue = false;
    }
  }
}
class SpaceShip {
  PImage ship;
  float angle, bulletAngle;
  ArrayList<PVector> bullets = new ArrayList<PVector>(); 

  SpaceShip() {
  }

  public void drawSpaceShip() {
    pushMatrix();
    ship = loadImage("spaceShip.jpg");
    ship.resize(50, 50);
    float x = width/2;
    float y = height/2;
    translate(x, y);
    angle = atan2(x-mouseX, y-mouseY);
    bulletAngle = atan2(x-mouseX, y-mouseY);
    rotate(-angle);
    imageMode(CENTER);
    image(ship, 0, 0);
    popMatrix();
  }
  
  public void shoot(){
    bullets.add(new PVector(mouseX, mouseY));
  }
  
}
  public void settings() {  fullScreen();  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "FinalGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
